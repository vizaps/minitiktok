class User {
    constructor(id, nome) {
        this.id = id;
        this.nome = nome;
    }
}

class IReaction {
    react(video, user) {
        throw new Error();
    }
    getReactionType() {
        throw new Error();
    }
}

class ICommentable {
    addComment(comment, user) {
        throw new Error();
    }
    getComments() {
        throw new Error();
    }
}

class Video extends ICommentable {
    constructor(id, titulo, url, dono) {
        super();
        this.id = id;
        this.titulo = titulo;
        this.url = url;
        this.dono = dono;
        this.reacoes = [];
        this.comentarios = [];
    }

    addComment(comment, user) {
        this.comentarios.push(`${user.nome}: ${comment}`);
    }

    getComments() {
        return [...this.comentarios];
    }

    addReaction(reaction) {
        this.reacoes.push(reaction);
    }

    applyReaction(reaction, user) {
        reaction.react(this, user);
        this.addReaction(reaction);
    }
}

class Like extends IReaction {
    react(video, user) {
        console.log(`${user.nome} curtiu o vídeo ${video.titulo}`);
    }
    getReactionType() {
        return "Curtida";
    }
}

class Love extends IReaction {
    react(video, user) {
        console.log(`${user.nome} amou o vídeo ${video.titulo}`);
    }
    getReactionType() {
        return "Amei";
    }
}

class Share extends IReaction {
    react(video, user) {
        console.log(`${user.nome} compartilhou o vídeo ${video.titulo}`);
    }
    getReactionType() {
        return "Compartilhar";
    }
}

class FeedService {
    constructor(videos = []) {
        this.videos = videos;
    }

    addVideo(video) {
        this.videos.push(video);
    }

    listVideos() {
        return this.videos;
    }
}

// App
const feedService = new FeedService();
const currentUser = new User("1", "Você");

const like = new Like();
const love = new Love();
const share = new Share();

const videoFeed = document.getElementById("video-feed");
const postVideoBtn = document.getElementById("post-video");
const videoTitleInput = document.getElementById("video-title");
const videoUrlInput = document.getElementById("video-url");

function renderVideos() {
    videoFeed.innerHTML = '';
    feedService.listVideos().forEach(video => {
        const videoCard = document.createElement('div');
        videoCard.className = 'video-card';
        videoCard.innerHTML = `
            <h3>${video.titulo}</h3>
            <p>Postado por: ${video.dono.nome}</p>
            <video controls src="${video.url}"></video>
            <p>${video.reacoes.length} reações</p>
            <div class="actions">
                <button class="like-btn" onclick="handleReaction('${video.id}', 'like')">👍 Curtir</button>
                <button class="love-btn" onclick="handleReaction('${video.id}', 'love')">❤️ Amei</button>
                <button class="share-btn" onclick="handleReaction('${video.id}', 'share')">🔄 Compartilhar</button>
            </div>
            <div class="comments">
                <h4>Comentários (${video.comentarios.length})</h4>
                <ul class="comment-list" id="comments-${video.id}">
                    ${video.comentarios.map(c => `<li>${c}</li>`).join('')}
                </ul>
                <input type="text" id="comment-${video.id}" placeholder="Escreva um comentário">
                <button onclick="handleComment('${video.id}')">Comentar</button>
            </div>
        `;
        videoFeed.appendChild(videoCard);
    });
}

function handleReaction(videoId, type) {
    const video = feedService.videos.find(v => v.id === videoId);
    if (!video) return;

    let reaction;
    switch (type) {
        case "like": reaction = like; break;
        case "love": reaction = love; break;
        case "share": reaction = share; break;
        default: return;
    }

    video.applyReaction(reaction, currentUser);
    renderVideos();
}

function handleComment(videoId) {
    const video = feedService.videos.find(v => v.id === videoId);
    if (!video) return;

    const input = document.getElementById(`comment-${videoId}`);
    const text = input.value.trim();
    if (text) {
        video.addComment(text, currentUser);
        input.value = '';
        renderVideos();
    }
}

postVideoBtn.addEventListener('click', () => {
    const title = videoTitleInput.value.trim();
    const url = videoUrlInput.value.trim();

    if (title && url) {
        const newVideo = new Video(`vid-${Date.now()}`, title, url, currentUser);
        feedService.addVideo(newVideo);
        videoTitleInput.value = '';
        videoUrlInput.value = '';
        renderVideos();
    }
});

// Vídeos de exemplo
const demoUser = new User("2", "Usuário Demo");
const video1 = new Video("v1", "Cachorro dançando", "https://www.w3schools.com/html/mov_bbb.mp4", demoUser);
const video2 = new Video("v2", "Gato miando", "https://www.w3schools.com/html/movie.mp4", demoUser);

feedService.addVideo(video1);
feedService.addVideo(video2);

renderVideos();